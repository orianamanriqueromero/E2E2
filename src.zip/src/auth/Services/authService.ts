import api from "../../api";
import type { AuthResponse, LoginRequest, RegisterRequest,
  User} from "../types/auth";
// function to login a user
export const login = async (
  data: LoginRequest
): Promise<AuthResponse> => {
    console.log("Enviando petición...");
  const response = await api.post<AuthResponse>("/auth/login", data);
console.log(response);
  return response.data;

};
// function to register a new user
export const register = async (
  data: RegisterRequest
): Promise<AuthResponse> => {
  const response = await api.post<AuthResponse>("/auth/register", data);

  return response.data;
};

// function to get the current user from the backend
export const getCurrentUser = async (): Promise<User> => {
  const response = await api.get<User>("/users/me");

  return response.data;
};
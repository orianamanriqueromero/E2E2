
import { useState } from "react";
import { login, register } from "../Services/authService";

function AuthPage() {

  const [isLogin, setIsLogin] = useState(true);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"PASSENGER" | "DRIVER">("PASSENGER");

  const handleSubmit = async (e:any) => {

    e.preventDefault();

    console.log("Entró al handleSubmit");

    try{

      if(isLogin){

        const response=await login({
          email,
          password
        });

        console.log(response);

      }else{

        const response=await register({

          firstName,
          lastName,
          email,
          password,
          role

        });

        console.log(response);

      }

    }catch(error){

      console.error(error);

    }

  }

  return (

    <div>

      <h1>Uber Clone</h1>

      <button onClick={()=>setIsLogin(true)}>
        Login
      </button>

      <button onClick={()=>setIsLogin(false)}>
        Register
      </button>

      <hr/>

      <form onSubmit={handleSubmit}>

        {!isLogin && (

          <>

          <input
            placeholder="First name"
            value={firstName}
            onChange={(e)=>setFirstName(e.target.value)}
          />

          <input
            placeholder="Last name"
            value={lastName}
            onChange={(e)=>setLastName(e.target.value)}
          />

          </>

        )}

        <input
          placeholder="Email"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
        />

        {!isLogin && (

          <select
            value={role}
            onChange={(e)=>setRole(e.target.value as "PASSENGER"|"DRIVER")}
          >

            <option value="PASSENGER">
              Passenger
            </option>

            <option value="DRIVER">
              Driver
            </option>

          </select>

        )}

        <button type="submit">

          {isLogin ? "Login" : "Register"}

        </button>

      </form>

    </div>

  );

}

export default AuthPage;